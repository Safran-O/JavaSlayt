package com.kenan.arababeyin;

public class Mudur {

    public String adSoyad;
    public int maas;

    // THIS - bu sınıfın kendi öğeleri anlamına geliyor

    public void ekranaMerhabaYaz(String adSoyad) {
        System.out.println("Merhaba");
        System.out.println("metoda yolladığın ad soyad: " + adSoyad);
        // en tepedeki nesneye ait adSoyadı baz aldık ama maas için metoda yollananı aldık
        System.out.println("oluşan nesneye ait ad soyad: " + this.adSoyad);
    }

    public Mudur() {
    }
    /*
    public Mudur(String adSoyad, int maas) {
        this.adSoyad = adSoyad;
        this.maas = maas;
    }
     */

    public Mudur(String adSoyad, int maas) {
        this.adSoyad = adSoyad;
        this.maas = maas;
    }
}
