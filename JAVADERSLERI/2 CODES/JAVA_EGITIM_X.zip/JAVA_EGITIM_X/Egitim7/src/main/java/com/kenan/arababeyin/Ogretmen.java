package com.kenan.arababeyin;

public class Ogretmen {

    public String adSoyad;
    public int maas;

    public Ogretmen(String ogretmeninAdiSoyadi) {
        adSoyad = ogretmeninAdiSoyadi;
        maas = 5000;
    }

    /* bu iptal oldu
    public Ogretmen(){
    } */
}
