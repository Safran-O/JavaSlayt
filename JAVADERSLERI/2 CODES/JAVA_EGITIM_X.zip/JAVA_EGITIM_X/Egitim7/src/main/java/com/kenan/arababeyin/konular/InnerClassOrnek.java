package com.kenan.arababeyin.konular;

public class InnerClassOrnek {

    public String okulAdi;
    public int ogrenciSayisi;
    public Sehir bulunduguSehir = new Sehir();

    /*
    INNER CLASS - class içinde class
     */
    public class Sehir{
        public int plaka;
        public String sehirAdi;
    }

    public void erisimTipleri(){
        KonuErisimTipleri konuErisimTipleri = new KonuErisimTipleri();
        konuErisimTipleri.falan = "asdsadasdas";
    }

}
