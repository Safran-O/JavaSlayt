package com.kenan.arababeyin;

import com.kenan.arababeyin.konular.InnerClassOrnek;
import com.kenan.arababeyin.konular.KonuErisimTipleri;
import com.kenan.arababeyin.konular.KonuStaticFinalConst;

public class AnaSinif {

    public static void main(String[] args) {

        System.out.println("------------------------");
        System.out.println("CONSTRUCTOR VE PARAMETRELİ CONSTRUCTOR");
        System.out.println("------------------------");

        Ogrenci ogrenci = new Ogrenci();
        System.out.println("Öğrenci: " + ogrenci.adSoyad + " yaş: " + ogrenci.yas);

        ogrenci.adSoyad = "Abraham Sweetvoice";
        ogrenci.yas = 70;
        System.out.println("Öğrenci: " + ogrenci.adSoyad + " yaş: " + ogrenci.yas);

        Ogrenci ogrenci1 = new Ogrenci(true);

        //
        Ogretmen ogretmen = new Ogretmen("Tünzile Çorlak");
        System.out.println("Öğretmen: " + ogretmen.adSoyad + " " + ogretmen.maas);

        System.out.println("------------------------");
        System.out.println("THIS kullanımı ve engüzelinden bir parametreli constructor");
        System.out.println("------------------------");

        Mudur mudur = new Mudur();
        mudur.adSoyad = "Murtaza Falan";
        mudur.maas = 6000;
        mudur.ekranaMerhabaYaz("Ahmet Filan");
        System.out.println("Müdür: " + mudur.adSoyad + " " + mudur.maas);

        Mudur mudur1 = new Mudur("Gılgamış Yolcu", 7500);
        System.out.println("Müdür: " + mudur1.adSoyad + " " + mudur1.maas);


        System.out.println("------------------------");
        System.out.println("GARBAGE COLLECTION");
        System.out.println("------------------------");
        //Ogrenci ogrenci1 = new Ogrenci();
        //Ogrenci ogrenci2 = new Ogrenci();
        //Ogrenci ogrenci3 = new Ogrenci();
        //Ogrenci ogrenci4 = new Ogrenci();
        //Ogrenci ogrenci5 = new Ogrenci();
        //// ........
        //Ogrenci ogrenci1000 = new Ogrenci();

        /*
        for (int i = 0; i<100000000; i++) {
            Ogrenci ogrrr = new Ogrenci();
        }
         */

        //System.gc(); // Garbage Collector'ı devreye alır
        // ANCAK asla tavsiye edilmez
        // GC çalışınca memory rahatlar ancak çalışırken cpu kasar
        // terminalden jconsole yazılır

        System.out.println("------------------------");
        System.out.println("INNER CLASS");
        System.out.println("------------------------");
        InnerClassOrnek okul1 = new InnerClassOrnek();
        okul1.okulAdi = "Cumhuriyet İ.Ö.O.";
        okul1.ogrenciSayisi = 300;
        okul1.bulunduguSehir.sehirAdi = "İstanbul";
        okul1.bulunduguSehir.plaka = 34;
        System.out.println("İlkokul bilgisi: " + okul1.okulAdi + " " + okul1.bulunduguSehir.sehirAdi);


        System.out.println("------------------------");
        System.out.println("ERİŞİM TİPLERİ");
        System.out.println("------------------------");

        KonuErisimTipleri konuErisimTipleri = new KonuErisimTipleri();
        konuErisimTipleri.adSoyad = "Mahmut Tuncerovskioğullarıgiller";
        //konuErisimTipleri.dogumYeri = "Urfa";
        //konuErisimTipleri.falan = "asdsadasdas";
        konuErisimTipleri.ekranaYazdir();
        //konuErisimTipleri.farkliIslemler();


        System.out.println("------------------------");
        System.out.println("STATIC / FINAL / CONST");
        System.out.println("------------------------");

        KonuStaticFinalConst x = new KonuStaticFinalConst(); // KonuStaticFinalConst bir sınıf ama x bir nesne
        KonuStaticFinalConst y = new KonuStaticFinalConst(); // bu yüzden x ve y'nin ayrı adSoyad'ları var
        x.adSoyad = "skdnlkdnfds";
        y.adSoyad = "60*9*876768";

        // static değişkenler nesneye has bir değişken olmadığı için direk sınıftan çağrılır.
        System.out.println("Adı Soyadı " + x.adSoyad + " Ülkesi: " + KonuStaticFinalConst.ulke);
        KonuStaticFinalConst.ulke = "EN";
        System.out.println("Adı Soyadı " + x.adSoyad + " Ülkesi: " + KonuStaticFinalConst.ulke);
        System.out.println("Adı Soyadı " + y.adSoyad + " Ülkesi: " + KonuStaticFinalConst.ulke);

        KonuStaticFinalConst.sirketAdiniYazdir();
        System.out.println("Adı Soyadı " + x.adSoyad + " Ülkesi: " + KonuStaticFinalConst.ulke);

        System.out.println("FINAL --------");
        System.out.println("X Gezegen: " + x.gezegen);
        System.out.println("Y Gezegen: " + y.gezegen);
        //x.gezegen = "asdasdasda";
        // final daha çok buradaki gibi metod içindeki değişkenlerde kullanılır
        final int maxDersNotu = 100; // bu 100 değeri örneğin database'den geldi
        System.out.println("Max ders notu: " + maxDersNotu);
        //maxDersNotu = 110;

        System.out.println("CONSTANT --------");
        //x.sirketAdi = "Mahmut Holding";
        //System.out.println("Şirket Adı: " + x.sirketAdi);
        //System.out.println("Şirket Adı: " + y.sirketAdi);
        System.out.println("Şirket Adı: " + KonuStaticFinalConst.sirketAdi);
        System.out.println("Şirket Adı: " + KonuStaticFinalConst.SIRKET_ADI);


    }

}
