package com.kenan.arababeyin;

public class Ogrenci {

    public String adSoyad;
    public int yas;

    // CONSTURCTOR
    // [erişim tipi] [sınıf adı] ([varsa paramatre]) {......}

    // DEFAULT CONSTRUCTOR - Eğer hiç constructor yazamazsanız bu aşağıdaki default olanı gizliden burada yazılı gibi olur
    /*
    public Ogrenci() {
    }
     */

    public Ogrenci() {
        System.out.println("Öğrenci yaratıldı.");
        adSoyad = "Unknown Artist";
        yas = 35;
    }

    // bir tane bile parametreli contructor yazarsanız yukarıdaki default'u yazmadığınız müddetçe yokmuş gibi davranır

    // PARAMETRELİ YAPICI METOD
    public Ogrenci(boolean zekiMi) {
        if (zekiMi) {
            System.out.println("zeki bir öğrenci yaratıldı");
        } else {
            System.out.println("Bu öğrenci ekstra zeki değil normal adam");
        }
    }


}
