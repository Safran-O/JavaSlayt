package com.kenan.arababeyin.konular;

public class KonuErisimTipleri {

    // PUBLIC her yerden ulaşılır
    // PRIVATE sadece sınıf içinden ulaşılır
    // PROTECTED ileride anlatılacak (kalıtım eğitiminden sonra)
    public String adSoyad;
    private String dogumYeri; // private olanlar genelde: birden fazla metodunda aynı değişkeni ve değerini kullancaksan o zaman işini görür
    protected String sehir;
    String falan; // erişim tipi verilmeyen değişkenler kendi sınıfı içinde ve aynı paket altındaki sınıflarda çağrılabilir.
    // ancak erişim tipsiz tanımlama yapmayın


    public void ekranaYazdir() {
        dogumYeri = "Hakkari";
        sehir = "NewYork";
        System.out.println("Şehrim: " + sehir);
        int deneme = 50;
        farkliIslemler();
    }

    private void farkliIslemler() {
        //deneme + 20;
        System.out.println("Memleketim: " + dogumYeri);
        System.out.println("private metod çalıştı");
    }

}
