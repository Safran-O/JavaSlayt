package com.kenan.arababeyin.konular;

public class KonuStaticFinalConst {

    // STATIC
    public String adSoyad; // her new'lenen KonuStaticFinal için bu değişkenden bir tane yaratıp ona özel atar
    // [erişim tipi] static [tipi] [değişken adı]
    // Her nesne için bir tane YARATMAZ, sınıf için genel bir tane yaratır ve her nesne sadece bu bir taneye ulaşır
    // yani static değişkenler ve metodlar nesneye öze ldeğildir. Tüm nesneler için ortaktır
    // veeee uygulama ayağa kalkar kalkmaz memory'de yer alır  ve uygulama durana kadar memory'den silinmez
    public static String ulke = "TR";

    public static void sirketAdiniYazdir(){
        System.out.println("TESTINIUM");
        ulke = "FR";
    }


    // FINAL
    // [erişim tipi] final [tipi] [değişken adı]
    // genelde metod içlerinde kullanılır
    public final String gezegen = "Dünya"; // genelde buradaki gibiden ziyade db'den okur atar değeri

    public void finalYazdir(){
        //gezegen = "Mars";
        System.out.println(gezegen);
        final String mimari = "Microservis";
        System.out.println("Uygulamanın mimarisi: " + mimari);
    }


    // CONSTANT
    // yani SABİTLER = FINAL ile STATIC'in birleşmiş halidir
    public static final String sirketAdi = "Testinium";
    // Doğru vir CONSTANT yazım stili
    public static final String SIRKET_ADI = "TESTINIUM A.Ş.";
    private static final String SIRKET_ADI2 = "LOADIUM A.Ş.";

    public void sabitleriYazdir(){
        System.out.println("Şirket Adı: " + SIRKET_ADI);
    }
}
