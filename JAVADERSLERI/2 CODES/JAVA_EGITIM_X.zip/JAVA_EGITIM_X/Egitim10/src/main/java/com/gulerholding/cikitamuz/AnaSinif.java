package com.gulerholding.cikitamuz;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AnaSinif {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("ÇİKİTA MUZ MUZ MUZ");

        System.out.println("----------------------------");
        System.out.println("EQUALS / HASHCODE / TO STRING");
        System.out.println("----------------------------");

        System.out.println("EQUALS -----------");
        Ogrenci ogrenci1 = new Ogrenci(1, "Ali", "Deli");
        Ogrenci ogrenci2 = new Ogrenci(2, "Mahmut", "Tuncer");
        Ogrenci ogrenci3 = new Ogrenci(3, "Serdar", "OrTouch"); // memory'de x342525235 yerini aldı
        Ogrenci ogrenci4 = new Ogrenci(3, "Serdar", "OrTouch"); // memory'de x9896587 yerini aldı

        int x = 5;
        int y = 5;
        if (x == y) {
            System.out.println("x değeri y değerine eşittir");
        }

        // pirmitive type olmayan tüüüüüm değişkenlerde (wrapper typelar dahil) == yerine .equals() kullanılır
        // çünkü == demek memory'deki yerlerini karşılaştırmak demek

        if (ogrenci3 == ogrenci4) {
            System.out.println("ogrenci3 ve ogrenci4 eşittir");
        } else {
            System.out.println("ogrenci3 ve ogrenci4 eşit değildir. Aslıdna doğru çünkü ikisi de memory'de farklı nesneler");
        }

        if (ogrenci3.equals(ogrenci4)) {
            System.out.println("işte şimdi oldu evet ogrenci3 ve ogrenci4 eşittir");
        }

        System.out.println("\tHASH CODE -----------\n");

        System.out.println("TO STRING -----------");

        System.out.println("Öğrenci3 : " + ogrenci3); // Öğrenci3 : com.gulerholding.cikitamuz.Ogrenci@22


        System.out.println("----------------------------");
        System.out.println("STRING");
        System.out.println("----------------------------");
        String yazi1 = "Merhaba";
        String yazi2 = "Dünya";
        String yazi3 = yazi1 + yazi2;

        StringBuffer str = new StringBuffer();
        str.append(yazi1);
        str.append(yazi2);
        yazi3 = str.toString();


        Date suan = new Date();
        System.out.println("TARİH: " + suan);

        Thread.sleep(5000);

        DateFormat dfm = new SimpleDateFormat("dd/MMMM/yyyy HH:mm:ss");
        String tarih = dfm.format(suan);
        System.out.println(tarih);

    }

}
