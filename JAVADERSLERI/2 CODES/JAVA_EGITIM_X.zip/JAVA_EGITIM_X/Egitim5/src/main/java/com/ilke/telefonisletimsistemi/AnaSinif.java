package com.ilke.telefonisletimsistemi;

import com.ilke.telefonisletimsistemi.konular.MetodOverloading;
import com.ilke.telefonisletimsistemi.konular.Ogrenci;

public class AnaSinif {

    public static void main(String[] args) {
        System.out.println("HATTARI HENZO - EĞİTİM 5");

        // String --> class'dır yani tanımlama yeridir
        // yazi --> değişkendir veya diğer adıyla nesnedir
        String yazi = new String(); // String yazan yer class(sınıf), yazi yazan yer object(nesne)
        String yazi1 = new String();
        String yazi2 = new String();
        Ogrenci ogrenciX = new Ogrenci(); // new ile ram'de yer alır
        Ogrenci ogrenci1 = new Ogrenci();
        Ogrenci ogrenci2 = new Ogrenci();

        yazi = "Mahmut";
        yazi1 = "Ali";

        System.out.println("Yazilar: " + yazi + " - " + yazi1);


        // NEW sayesinde ram'de yer alır ve bir nesne haline gelir

        // Ogrenci --> sınıf
        // aliOgrencisi --> nesne
        Ogrenci aliOgrencisi = new Ogrenci(); // new Ogrenci() --> dediğim için de gider memoryde yer alır
        Ogrenci mahmutOgrencisi = new Ogrenci();
        Ogrenci tugbaOgrencisi; // memory'de yeri yoktur. yani sadece kağıt üzerinde yazılı

        //tugbaOgrencisi.adi = "Tuğba"; // new'lenmediği için değerlerini dolduramadım
        tugbaOgrencisi = new Ogrenci(); // şimdi bir anlamı oldu
        tugbaOgrencisi.adi = "Tuğba";
        tugbaOgrencisi.soyadi = "Falan";
        tugbaOgrencisi.yas = 14;

        aliOgrencisi.adi = "Ali";
        aliOgrencisi.soyadi = "Yılmaz";
        aliOgrencisi.yas = 13;

        System.out.println("Öğrenci bilgisi: " + tugbaOgrencisi.adi + " " + tugbaOgrencisi.soyadi + " yaşı: " + tugbaOgrencisi.yas);
        System.out.println("Öğrenci bilgisi: " + aliOgrencisi.adi + " " + aliOgrencisi.soyadi + " yaşı: " + aliOgrencisi.yas);


        // Tüm öğrenciler için tanımlama amaçlı bir sınıf yazdık (Ogrenci) ama her bir gerçek öğrenci için ayrı ayrı new'ledik.
        Ogrenci ogr1 = new Ogrenci(); // memory'de x5660900 adresinde yer aldı
        ogr1.adi = "Pavoritti";
        ogr1.yas = 65;
        System.out.println("Öğrenci1: " + ogr1.adi + " yaş: " + ogr1.yas);

        Ogrenci ogr2 = new Ogrenci(); // memory'de x7788991122 adresinde yer aldı
        ogr2.adi = "Mustafa";
        ogr2.yas = 35;
        System.out.println("Öğrenci2: " + ogr2.adi + " yaş: " + ogr2.yas);

        ogr1.adi = "Mozart";
        System.out.println("Öğrenci1: " + ogr1.adi + " yaş: " + ogr1.yas);
        ogr2.adi = "Abuzittin";
        System.out.println("Öğrenci2: " + ogr2.adi + " yaş: " + ogr2.yas);

        ogr1.adi = ogr2.adi;
        System.out.println("Öğrenci1: " + ogr1.adi + " yaş: " + ogr1.yas + " / " + "Öğrenci2: " + ogr2.adi + " yaş: " + ogr2.yas);

        ogr2.adi = "Murtaza";
        System.out.println("Öğrenci1: " + ogr1.adi + " yaş: " + ogr1.yas + " / " + "Öğrenci2: " + ogr2.adi + " yaş: " + ogr2.yas);

        // ARA BİLGİLENDİRME
        // String'lerde == yani eşitmidir kontrolünü "==" ile yapmıyoruz .equals ile yapıyoruz.
        // Çünkü == işareti nesnelerde değerine bakmaz memory'deki yerine bakar

        ogr1 = ogr2; // iki nesneyi direk birbirine eşittir ile atama yaparsanız gider o nesnenin memory'deki yerini alır
        // ogr2'ye ait memory'i artık ogr1 için de kullanır ve ogr1 x5660900 adresten silinip direk x7788991122 adresine bakar
        // bu saatten sonra ogr1 nedemek ise ogr2'de o demektir ikisi de aslında tek kişi
        System.out.println("Öğrenci1: " + ogr1.adi + " yaş: " + ogr1.yas + " / " + "Öğrenci2: " + ogr2.adi + " yaş: " + ogr2.yas);

        ogr1.adi = "Kemal";
        System.out.println("Öğrenci1: " + ogr1.adi + " yaş: " + ogr1.yas + " / " + "Öğrenci2: " + ogr2.adi + " yaş: " + ogr2.yas);

        ogr2.adi = "Sevda";
        System.out.println("Öğrenci1: " + ogr1.adi + " yaş: " + ogr1.yas + " / " + "Öğrenci2: " + ogr2.adi + " yaş: " + ogr2.yas);

        // NEW DEDİĞİNİZ İKİ NESNEYİ BİRBİRİNE EŞİTLERSENİZ ARTIK İLKİ ÖLÜR İKİNCİSİNE BAKAR MEMORY'DE
        // YUKARIDAKİ OLAYA UYMAYAN BAZI DURUMLAR VAR
        // PRIMITIVE TYPE'LAR BİR NESNE DEĞİLDİR
        int x = 5;
        int y = 10;
        System.out.println("Sonuç x= " + x + " y= " + y);
        x = y; // y'nin memory'sine bakmaz da değeri neyse onu alır kendi memory hanesine yazar
        System.out.println("Sonuç x= " + x + " y= " + y);
        y = 20;
        System.out.println("Sonuç x= " + x + " y= " + y);


        // OVERLOADING
        System.out.println("----- OVERLOADING -----");
        MetodOverloading metodOverloading = new MetodOverloading();
        int sonuc1 = metodOverloading.topla();
        int sonuc2 = metodOverloading.topla(3.4d, 7);
        int sonuc3 = metodOverloading.topla(3, 7);
        int sonuc4 = metodOverloading.topla(3, 7.2d);
        int sonuc5 = metodOverloading.topla(3, 7, 9);
        System.out.println("Sonuçlar: " + sonuc4);
    }

}
