package com.ilke.telefonisletimsistemi.konular;

public class Ogrenci {

    public String adi;
    public String soyadi;
    public int yas;


}
