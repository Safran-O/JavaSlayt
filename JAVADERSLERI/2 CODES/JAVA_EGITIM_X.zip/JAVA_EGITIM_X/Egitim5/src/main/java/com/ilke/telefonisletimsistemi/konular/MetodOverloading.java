package com.ilke.telefonisletimsistemi.konular;

public class MetodOverloading {


    // DEĞİŞKEN
    // [erişim tipi] [veri tipi] [değişken adı] = [varsa değeri];

    // METOD
    // [erişim tipi] [dönüş tipi] [metod adı](varsa [degiskenler]) { ..... };

    public void ekranaMerhabaYaz() { // ekranaMerhabaYaz ( )
        System.out.println("hellö");
    }
    /*
    public void ekranaMerhabaYaz() { // ekranaMerhabaYaz ( )
    }
     */
    /*
    public int ekranaMerhabaYaz() { // ekranaMerhabaYaz ( )
        System.out.println("hellö");
        return 0;
    }
    */

    // topla(-)
    public int topla() {
        return 5 + 6;
    }
    /*
    // topla(-)
    public String topla(){
        return "adasd";
    }
     */

    // topla(int, int)
    public int topla(int x, int y) {
        // işlemler yapıyor
        return x + y;
    }

    /*
    // topla(int, int)
    public int topla(int a, int b){
        // işlemler yapıyor
        return a + b;
    }
     */

    // topla(int, int, int)
    public int topla(int x, int y, int z) {
        return x + y + z;
    }

    // topla(int, double)
    public int topla(int x, double y) {
        double sonuc = x + y;
        return new Double(sonuc).intValue();
    }

    // topla(double, int)
    public int topla(double x, int y) {
        double sonuc = x + y;
        return new Double(sonuc).intValue();
    }
}
