public class Mahmut {

    public static void main(String[] args) {
        System.out.println("Helloğ Wörlt");
        System.out.println("Helloğ Wörlt");
        System.out.println("Helloğ Wörlt");
        System.out.println("Helloğ Wörlt");
        System.out.println("Helloğ Wörlt");
    }

}
