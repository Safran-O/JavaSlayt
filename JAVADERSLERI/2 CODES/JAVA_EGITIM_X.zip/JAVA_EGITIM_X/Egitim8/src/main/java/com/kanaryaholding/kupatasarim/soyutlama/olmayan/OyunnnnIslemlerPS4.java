package com.kanaryaholding.kupatasarim.soyutlama.olmayan;

public class OyunnnnIslemlerPS4 {

    public String oyunIndir(){
        return "CS-GO";
    }

    public void gameOyna(String oyunAdi) {
        System.out.println("PS4 üzerinde " + oyunAdi + " oynanıyor");
    }

}
