package com.kanaryaholding.kupatasarim.kalitim;

public class Kopek extends Hayvan{

    private int kokuAlmaSeviyesi; // köpeğe özel
    private int benekSayisi; // köpeğe özel

    @Override
    public void sesCikar() {
        System.out.println("Hav hav");
    }

    public Kopek() {
        System.out.println("Köpek nesnesi yaratıldı");
    }

    public int getKokuAlmaSeviyesi() {
        return kokuAlmaSeviyesi;
    }

    public void setKokuAlmaSeviyesi(int kokuAlmaSeviyesi) {
        this.kokuAlmaSeviyesi = kokuAlmaSeviyesi;
    }

    public int getBenekSayisi() {
        return benekSayisi;
    }

    public void setBenekSayisi(int benekSayisi) {
        this.benekSayisi = benekSayisi;
    }
}
