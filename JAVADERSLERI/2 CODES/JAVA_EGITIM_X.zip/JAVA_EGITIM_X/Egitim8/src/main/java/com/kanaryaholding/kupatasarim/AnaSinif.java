package com.kanaryaholding.kupatasarim;

import com.kanaryaholding.kupatasarim.kapsulleme.Ogrenci;
import com.kanaryaholding.kupatasarim.kapsulleme.Ogretmen;
import com.kanaryaholding.kupatasarim.kalitim.Hayvan;
import com.kanaryaholding.kupatasarim.kalitim.Kedi;
import com.kanaryaholding.kupatasarim.kalitim.Kopek;
import com.kanaryaholding.kupatasarim.kalitim.Kus;
import com.kanaryaholding.kupatasarim.kalitim.servis.HayvanVermeServisi;
import com.kanaryaholding.kupatasarim.kalitim.kalitimolmayan.Cat;
import com.kanaryaholding.kupatasarim.kalitim.kalitimolmayan.Dog;
import com.kanaryaholding.kupatasarim.soyutlama.GameIslemler;
import com.kanaryaholding.kupatasarim.soyutlama.GameIslemlerPC;
import com.kanaryaholding.kupatasarim.soyutlama.GameIslemlerPCWinXP;
import com.kanaryaholding.kupatasarim.soyutlama.GameIslemlerPS4;
import com.kanaryaholding.kupatasarim.soyutlama.GameIslemlerXBOX;
import com.kanaryaholding.kupatasarim.soyutlama.abstractt.OyunIslemler;
import com.kanaryaholding.kupatasarim.soyutlama.abstractt.OyunIslemlerPC;
import com.kanaryaholding.kupatasarim.soyutlama.olmayan.OyunIslemlerrrPC;
import com.kanaryaholding.kupatasarim.soyutlama.olmayan.OyunnnnIslemlerPS4;
import com.kanaryaholding.kupatasarim.soyutlama.olmayan.OyunsalIslemXBoxMicrosoft;

public class AnaSinif {

    public static void main(String[] args) {

        System.out.println("MERHABA DÜNYA");

        /*
        OBJECT ORIENTED PROGRAMMING (OOP) - NESNE YÖNELİMLİ PROGRAMLAMA

Encapsulation - getter setter (private)
Inheritance - extends yani kalıtım (protected) - bir tane extends yapabilirsiniz
Polymorphizm - override yani metodu ezersin
Abstraction - soyutlama yani interface/implements veya abstract/extends ile tanımlamalar yazma

         */

        System.out.println("------------------------");
        System.out.println("1. ENCAPSULATION");
        System.out.println("------------------------");

        Ogrenci ogr1 = new Ogrenci();
        ogr1.adSoyad = "Fatmanur Yaylaaltı";
        //ogr1.yas = 20;
        System.out.println("Öğrenci : " + ogr1.adSoyad + " yaş:");
        ogr1.icerideCilginSeylerYap(21);
        System.out.println("Öğrenci : " + ogr1.adSoyad + " yaş:" + ogr1.yasBilgisiniVer());

        //
        // EN DOĞRU KULLANIM TARZI
        //
        Ogretmen ogretmen = new Ogretmen();
        ogretmen.setAdSoyad("Ahmet Aksoy");
        ogretmen.setYas(25);
        System.out.println("Öğretmen: " + ogretmen.getAdSoyad() + " yaş: " + ogretmen.getYas());

        Ogretmen ogretmen2 = new Ogretmen("Mahmut Tuncergiller", 56);
        System.out.println("Öğretmen: " + ogretmen2.getAdSoyad() + " yaş: " + ogretmen2.getYas());


        System.out.println("------------------------");
        System.out.println("2. INHERITANCE");
        System.out.println("------------------------");

        Cat cat = new Cat();
        cat.setAdi("Fıstıkçışahap");
        cat.setCinsi("Tekir");
        cat.setYas(2);
        cat.setBiyikBoyu(3.2f);
        cat.setRenk("Beyaz");

        Dog dog = new Dog("Köpekovski", "Bulldog", 3, "mor", 9, 100);

        System.out.println("Kedi: " + cat.getAdi() + " " + cat.getBiyikBoyu());
        System.out.println("Köpek: " + dog.getAdi() + " " + dog.getBenekSayisi());


        System.out.println("Kalıtım olan haliyle doğru bir çalışma --------------");
        Kedi kedi = new Kedi();
        kedi.setAdi("Fiştik");
        kedi.setCinsi("Takır");
        kedi.setRenk("Mor");
        kedi.setYas(3);
        kedi.setBiyikBoyu(3.1f);

        Kopek kopek = new Kopek();
        kopek.setAdi("Çovçov");
        kopek.setCinsi("Golden");
        kopek.setRenk("Siyah");
        kopek.setYas(2);
        kopek.setBenekSayisi(4);
        kopek.setKokuAlmaSeviyesi(100);

        Kus kus = new Kus();
        kus.setAdi("Maviş");
        kus.setCinsi("Papağan");
        kus.setRenk("Gökkuşağı");
        kus.setYas(1);
        kus.setUcmaYuksekligi(1000);

        System.out.println("Kedi: " + kedi.getAdi() + " " + kedi.getBiyikBoyu());
        System.out.println("Köpek: " + kopek.getAdi() + " " + kopek.getBenekSayisi());
        System.out.println("Kuş: " + kus.getAdi() + " " + kus.getUcmaYuksekligi());


        System.out.println("PROTECTED --------------------------------------");
        kedi.buBirPublicMetod();
        //kedi.buBirPrivateMetod();
        //kedi.buBirProtectedMetodYaniEvladaKalanMal();
        kedi.protectedKonusuIcinBirMetod();

        kedi.sesCikar(); // Hayvan Sesi
        kopek.sesCikar(); // Hayvan Sesi
        kus.sesCikar(); // Hayvan Sesi

        System.out.println("------------------------");
        System.out.println("3. POLYMORPHISM -----");
        System.out.println("------------------------");

        kedi.sesCikar(); // Miyav
        kopek.sesCikar(); // Hav Hav
        kus.sesCikar(); // Hayvan Sesi

        System.out.println("SUPER --------------------------------------");
        System.out.println("THIS derseniz: kendi sınıfı");
        System.out.println("SUPER derseniz: ata sınıfı");

        kedi.sesCikar(); // Miyav
        kopek.sesCikar(); // Hav Hav
        kus.sesCikar(); // Hayvan Sesi Cik Cik

        System.out.println("Constructor Sıralaması --------------------");
        Kedi kedi2 = new Kedi(); // new Hayvan() + new Kedi()
        Kopek kopek2 = new Kopek(); // new Hayvan() + new Kopek()


        System.out.println("instance of ------------------------------");
        Hayvan hayvan = new Hayvan();
        Hayvan hayvan1 = new Kedi();
        //Kedi kedi1 = new Hayvan();

        Kedi kedi1 = new Kedi();
        if (kedi1 instanceof Kedi) {
            System.out.println("- instance of - evet kedi1 bir Kedi sınıfıdır");
        }
        if (kedi1 instanceof Hayvan) {
            System.out.println("- instance of - evet kedi1 bir Hayvan sınıfıdır");
        }

        Hayvan hayvan2 = new Kedi();
        hayvan2.setAdi("asdasdas");
        ((Kedi) hayvan2).setBiyikBoyu(3.4f); // type casting yaparak geldi
        if (hayvan2 instanceof Hayvan) {
            System.out.println("- instance of - evet hayvan2 bir Hayvan sınıfıdır");
        }
        if (hayvan2 instanceof Kedi) {
            System.out.println("- instance of - evet hayvan2 bir Kedi sınıfıdır");
        }
        if (hayvan2 instanceof Kopek) {
            System.out.println("- instance of - evet hayvan2 bir Köpek sınıfıdır");
        }

        HayvanVermeServisi hayvanVermeServisi = new HayvanVermeServisi();
        Hayvan hayvan3 = hayvanVermeServisi.birHayvanVer();
        if(hayvan3 instanceof Kedi) {
            System.out.println("- instance of - evet hayvan3 bir Kedi sınıfıdır");
            ((Kedi) hayvan3).setBiyikBoyu(23);
        } else if(hayvan3 instanceof Kopek) {
            System.out.println("- instance of - evet hayvan3 bir Kopek sınıfıdır");
            ((Kopek) hayvan3).setBenekSayisi(23);
        } else if(hayvan3 instanceof Kus) {
            System.out.println("- instance of - evet hayvan3 bir Kus sınıfıdır");
            ((Kus) hayvan3).setUcmaYuksekligi(100);
        } else {
            System.out.println("- instance of - evet hayvan3 bir Hayvan sınıfıdır");
        }

        System.out.println("------------------------");
        System.out.println("4. ABSTRACTION -----");
        System.out.println("------------------------");

        System.out.println("------------------------");
        System.out.println("4.1. INTERFACE -----");
        System.out.println("------------------------");

        System.out.println("interface olmayan -------------------------");
        OyunIslemlerrrPC oyunIslemlerrrPC = new OyunIslemlerrrPC();
        String indirilenOyun = oyunIslemlerrrPC.oyunDownload();
        oyunIslemlerrrPC.oyunPlay(indirilenOyun);

        OyunnnnIslemlerPS4 oyunnnnIslemlerPS4 = new OyunnnnIslemlerPS4();
        String indirilenOyunPS4 = oyunnnnIslemlerPS4.oyunIndir();
        oyunnnnIslemlerPS4.gameOyna(indirilenOyunPS4);

        OyunsalIslemXBoxMicrosoft oyunsalIslemXBoxMicrosoft = new OyunsalIslemXBoxMicrosoft();
        int indirilenOyunXBOX = oyunsalIslemXBoxMicrosoft.gameDownloadsCSGO();
        oyunsalIslemXBoxMicrosoft.gamePlayWithName(indirilenOyunXBOX);

        System.out.println("interface olan ---------------------------");
        GameIslemler gameIslemlerPC = new GameIslemlerPC();
        String oyunPC = gameIslemlerPC.oyunIndir();
        gameIslemlerPC.oyunOyna(oyunPC);
        System.out.println("---");

        GameIslemler gameIslemlerXBOX = new GameIslemlerXBOX();
        String oyunXBOX = gameIslemlerXBOX.oyunIndir();
        gameIslemlerXBOX.oyunOyna(oyunXBOX);
        System.out.println("---");

        GameIslemlerPS4 gameIslemlerPS4 = new GameIslemlerPS4();
        gameIslemlerPS4.playstationStoreBaglan();
        String oyunPS4 = gameIslemlerPS4.oyunIndir();
        gameIslemlerPS4.oyunOyna(oyunPS4);
        System.out.println("---");

        GameIslemlerPCWinXP gameIslemlerPCWinXP = new GameIslemlerPCWinXP();
        String oyunPCWinXP = gameIslemlerPCWinXP.oyunIndir();
        gameIslemlerPCWinXP.oyunOyna(oyunPCWinXP);

        System.out.println("------------------------");
        System.out.println("4.2. ABSTRACT -----");
        System.out.println("------------------------");
        OyunIslemler oyunIslemler = new OyunIslemlerPC();
        OyunIslemlerPC oyunIslemlerPC = new OyunIslemlerPC();

        oyunIslemlerPC.falan();
        System.out.println(oyunIslemlerPC.filan(34));
        String oyunIndir = oyunIslemlerPC.oyunIndir();
        oyunIslemlerPC.oyunOyna(oyunIndir);


    }

}
