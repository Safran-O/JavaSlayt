package com.kanaryaholding.kupatasarim.kapsulleme;

public class Ogrenci {

    public String adSoyad;
    private int yas; // default değeri 0

    public void icerideCilginSeylerYap(int atancakYasDegeri) {
        System.out.println("yaş: " + yas);
        yas = atancakYasDegeri - 2;
        System.out.println("yaş: " + yas);
    }

    public int yasBilgisiniVer(){
        return yas - 1;
    }

}
