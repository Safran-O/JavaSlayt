package com.kanaryaholding.kupatasarim.kalitim;

public class Kus extends Hayvan {

    private int ucmaYuksekligi;

    // SUPER
    @Override
    public void sesCikar() {
        super.sesCikar();
        System.out.println("Cik cik");
    }

    public int getUcmaYuksekligi() {
        return ucmaYuksekligi;
    }

    public void setUcmaYuksekligi(int ucmaYuksekligi) {
        this.ucmaYuksekligi = ucmaYuksekligi;
    }
}
