package com.kanaryaholding.kupatasarim.soyutlama;

public class GameIslemlerPCWinXP extends GameIslemlerPC {

    @Override
    public void oyunOyna(String oyunAdi) {
        System.out.println("XP'ye göre ayarlar yapıldı");
        super.oyunOyna(oyunAdi);
    }
}
