package com.kanaryaholding.kupatasarim.kalitim;

public class Papagan extends Kus {

    @Override
    public void sesCikar() {
        super.sesCikar();
        renk = "renkli";
    }
}
