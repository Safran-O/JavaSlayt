package com.kanaryaholding.kupatasarim.kalitim.kalitimolmayan;

public class Cat {

    private String adi;
    private String cinsi;
    private int yas;
    private String renk;
    private float biyikBoyu; // kediye özel

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public String getCinsi() {
        return cinsi;
    }

    public void setCinsi(String cinsi) {
        this.cinsi = cinsi;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        this.yas = yas;
    }

    public String getRenk() {
        return renk;
    }

    public void setRenk(String renk) {
        this.renk = renk;
    }

    public float getBiyikBoyu() {
        return biyikBoyu;
    }

    public void setBiyikBoyu(float biyikBoyu) {
        this.biyikBoyu = biyikBoyu;
    }

}
