package com.kanaryaholding.kupatasarim.soyutlama;

public interface PlayStationTemelIslemler {

    void playstationStoreBaglan();

}
