package com.kanaryaholding.kupatasarim.soyutlama.olmayan;

public class OyunIslemlerrrPC {

    public String oyunDownload(){
        return "CS-GO";
    }

    public void oyunPlay(String oyunAdi){
        System.out.println(oyunAdi + " oyunu oynanıyor bilgisayarda");
    }
}
