package com.kanaryaholding.kupatasarim.kalitim;

public class Hayvan {

    private String adi;
    private String cinsi;
    private int yas;
    protected String renk; // PROTECTED erişim tipi ile sadece kendi sınıfı ve türeyen sınıflardan direk ulaşılabilir

    public Hayvan() {
        System.out.println("Hayvan nesnesi yaratıldı");
    }

    protected void buBirProtectedMetodYaniEvladaKalanMal() {
        System.out.println("protected konusunu işliyoruz");
    }

    public void buBirPublicMetod(){
        System.out.println("public metod");
    }

    private void buBirPrivateMetod(){
        System.out.println("private metod");
    }

    // POLYMORPHISM
    public void sesCikar() {
        System.out.println("Hayvan Sesi");
    }

    // GETTER SETTER

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public String getCinsi() {
        return cinsi;
    }

    public void setCinsi(String cinsi) {
        this.cinsi = cinsi;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        this.yas = yas;
    }

    public String getRenk() {
        return renk;
    }

    public void setRenk(String renk) {
        this.renk = renk;
    }
}
