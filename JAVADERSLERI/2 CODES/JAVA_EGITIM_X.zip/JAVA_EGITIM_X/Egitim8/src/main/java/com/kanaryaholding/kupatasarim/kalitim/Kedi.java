package com.kanaryaholding.kupatasarim.kalitim;

public class Kedi extends Hayvan {

    private float biyikBoyu;

    // PROTECTED
    public void protectedKonusuIcinBirMetod(){
        //adi = "Tipitip";
        setAdi("Tipitip");
        renk = "beyaz";

        buBirPublicMetod();
        //buBirPrivateMetod();
        buBirProtectedMetodYaniEvladaKalanMal();
    }

    // POLYMORPHISM
    @Override
    public void sesCikar() {
        System.out.println("Miyav");
    }

    public Kedi() {
        System.out.println("Kedi Sınıfı yaratıldı");
    }

    public float getBiyikBoyu() {
        return biyikBoyu;
    }

    public void setBiyikBoyu(float biyikBoyu) {
        this.biyikBoyu = biyikBoyu;
    }
}
