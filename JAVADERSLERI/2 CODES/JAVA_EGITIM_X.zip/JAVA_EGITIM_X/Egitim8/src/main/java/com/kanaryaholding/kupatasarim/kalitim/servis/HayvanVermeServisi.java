package com.kanaryaholding.kupatasarim.kalitim.servis;

import com.kanaryaholding.kupatasarim.kalitim.Kopek;

public class HayvanVermeServisi {

    public Kopek birHayvanVer(){
        Kopek kopek = new Kopek();
        kopek.setAdi("Çovçov");
        kopek.setCinsi("Golden");
        kopek.setRenk("Siyah");
        kopek.setYas(2);
        kopek.setBenekSayisi(4);
        kopek.setKokuAlmaSeviyesi(100);
        return kopek;
    }

}
