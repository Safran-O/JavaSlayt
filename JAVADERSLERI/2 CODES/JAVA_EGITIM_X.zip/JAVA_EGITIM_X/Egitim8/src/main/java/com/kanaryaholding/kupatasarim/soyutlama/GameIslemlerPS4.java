package com.kanaryaholding.kupatasarim.soyutlama;

public class GameIslemlerPS4 implements GameIslemler, PlayStationTemelIslemler {

    @Override
    public String oyunIndir() {
        return "CS-GO PS4 Edition";
    }

    @Override
    public void oyunOyna(String oyunAdi) {
        System.out.println(oyunAdi + " oyunu PS4'de oynanıyor");
    }

    @Override
    public void playstationStoreBaglan() {
        System.out.println("PS4 için olan repoya bağlandım");
    }
}
