package com.kanaryaholding.kupatasarim.kapsulleme;

public class Ogretmen {

    /*
        ŞİMDİYE KADAR YAZDIĞIMIZ PUBLİC DEĞİŞKENLERİ ARTIK BUNDAN SONRA HİÇ YAZMAYACAĞIZ VE GERÇEK HAYATTA DA BÖYLE YAPILIR
     */
    private String adSoyad;
    private int yas;

    public Ogretmen() {
    }

    public Ogretmen(String adSoyad, int yas) {
        this.adSoyad = adSoyad;
        this.yas = yas;
    }

    // GETTER - SETTER

    public String getAdSoyad() {
        return "Sayın " + adSoyad;
    }

    public void setAdSoyad(String adSoyad) {
        this.adSoyad = adSoyad;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        this.yas = yas;
    }
}
