package com.kanaryaholding.kupatasarim.soyutlama.olmayan;

public class OyunsalIslemXBoxMicrosoft {

    public int gameDownloadsCSGO(){
        return 9087;
    }

    public void gamePlayWithName(int oyunId) {
        System.out.println(oyunId + " oyununu XBOX'da oynuyoruz gardaş");
    }
}
