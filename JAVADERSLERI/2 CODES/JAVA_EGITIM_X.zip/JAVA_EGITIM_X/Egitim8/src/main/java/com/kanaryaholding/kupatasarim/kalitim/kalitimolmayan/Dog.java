package com.kanaryaholding.kupatasarim.kalitim.kalitimolmayan;

public class Dog {

    private String adi;
    private String cinsi;
    private int yas;
    private String renk;
    private int kokuAlmaSeviyesi; // köpeğe özel
    private int benekSayisi; // köpeğe özel

    public Dog() {
    }

    public Dog(String adi, String cinsi, int yas, String renk, int kokuAlmaSeviyesi, int benekSayisi) {
        this.adi = adi;
        this.cinsi = cinsi;
        this.yas = yas;
        this.renk = renk;
        this.kokuAlmaSeviyesi = kokuAlmaSeviyesi;
        this.benekSayisi = benekSayisi;
    }

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public String getCinsi() {
        return cinsi;
    }

    public void setCinsi(String cinsi) {
        this.cinsi = cinsi;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        this.yas = yas;
    }

    public String getRenk() {
        return renk;
    }

    public void setRenk(String renk) {
        this.renk = renk;
    }

    public int getKokuAlmaSeviyesi() {
        return kokuAlmaSeviyesi;
    }

    public void setKokuAlmaSeviyesi(int kokuAlmaSeviyesi) {
        this.kokuAlmaSeviyesi = kokuAlmaSeviyesi;
    }

    public int getBenekSayisi() {
        return benekSayisi;
    }

    public void setBenekSayisi(int benekSayisi) {
        this.benekSayisi = benekSayisi;
    }

}
