package com.kanaryaholding.kupatasarim.soyutlama;

public interface GameIslemler {

    // [dönüş tipi] [metod adı] ([varsa parametreler])

    String oyunIndir();

    void oyunOyna(String oyunAdi);

    // veya değişken tutabiliyorsunuz

}
