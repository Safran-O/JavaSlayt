package com.goksuholding.sudagitim.util;

import java.util.Scanner;

public class KosullarCalisma {


    /**
     * Bu metod if konusunu içermektedir. çok kullanılır
     */
    public void konsolaIfKonusuIleIlgiliSeyleriYazdir() {
        System.out.println("--------------- IF --------------");

        int x = 70;
        int y = 50;

        if (x < y) {
            System.out.println("x değeri y değerinden küçük");
        } else {
            System.out.println("x değeri y değerinden büyük");
        }

        /*System.out.println("Not giriniz: ");
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        String not = myObj.nextLine();  // Read user input
        int sinavNotu = new Integer(not); */
        int sinavNotu = 35;
        if (sinavNotu > 90) {
            System.out.println("NOT: AA");
        } else if (sinavNotu > 70) {
            System.out.println("NOT: BB");
        } else if (sinavNotu > 50) {
            System.out.println("NOT: CC");
        } else {
            System.out.println("NOT: FF (Başarısız)");
        }

    }

    /**
     * bu metod switch konusunu kapsar, az kullanılır
     */
    public void konsolaSwitchKonusuIleIlgiliSeyleriYazdir() {
        System.out.println("--------------- SWITCH --------------");
        int sayi = 123;

        switch (sayi) {
            case 100:
                System.out.println("sayi 100");
                break;
            case 200:
                System.out.println("sayi 200");
                break;
            default:
                System.out.println("sayi 100 veya 200 değil. sayi:" + sayi);
                break;
        }
    }

    /**
     * çok kullanılmaz
     */
    public void konsolaIfKonusuIleIlgiliFarkliYazdir() {
        System.out.println("--------------- ?: --------------");
        int x = 100;
        int y = 40;

        int result;
        if (x < y) {
            result = x + y;
        } else {
            result = x - y;
        }
        System.out.println("Sonuç: " + result);

        // yukarıdaki if ile aynı şeyi yapar
        result = (x < y) ? (x + y) : (x - y);
        System.out.println("? : örneği sonucu: " + result);
    }

}
