package com.goksuholding.sudagitim;

import com.goksuholding.sudagitim.util.DongulerCalisma;
import com.goksuholding.sudagitim.util.KosullarCalisma;

public class AnaSinif {

    public static void main(String[] args) {

        System.out.println("LÖ HELLÖĞ, LÖ POĞSİYON LÖ KEBAB");

        System.out.println("-----------------");
        System.out.println("KOŞULLAR");
        System.out.println("-----------------");

        //KosullarCalisma degisken1 = new KosullarCalisma();
        KosullarCalisma kosullarCalisma = new KosullarCalisma();
        kosullarCalisma.konsolaIfKonusuIleIlgiliSeyleriYazdir();
        kosullarCalisma.konsolaSwitchKonusuIleIlgiliSeyleriYazdir();
        kosullarCalisma.konsolaIfKonusuIleIlgiliFarkliYazdir();


        System.out.println("-----------------");
        System.out.println("DÖNGÜLER");
        System.out.println("-----------------");

        DongulerCalisma dongulerCalisma = new DongulerCalisma();
        dongulerCalisma.konsolaForDongusuIleIlgiliSeylerYazdir();
        dongulerCalisma.konsolaWhileDongusuIleIlgiliSeylerYazdir();
        dongulerCalisma.konsolaDoWhileDongusuIleIlgiliSeylerYazdir();
        dongulerCalisma.konsolaIcIceForKonusuIleIlgiliSeyleriYazdir();

    }

}
