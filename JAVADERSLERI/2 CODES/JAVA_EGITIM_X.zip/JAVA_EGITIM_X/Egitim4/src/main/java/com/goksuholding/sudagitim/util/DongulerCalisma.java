package com.goksuholding.sudagitim.util;

public class DongulerCalisma {

    /**
     * çok kullanılır
     */
    public void konsolaForDongusuIleIlgiliSeylerYazdir() {
        System.out.println("-------------- FOR --------------");
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
        int x = 1;
        System.out.println(x++);
        System.out.println(x++);
        System.out.println(x++);
        // ....

        //for (int sayac = 0; sayac < 5; sayac = sayac + 1) {
        //for (int sayac = 0; sayac < 5; sayac += 1) {
        for (int sayac = 0; sayac < 5; sayac++) {
            System.out.println("for döngüsü sayaç: " + sayac);
        }

        for (int i = 0; i <= 100; i += 20) {
            System.out.println("2. For Döngüsü sayac değeri: " + i);
        }
    }


    public void konsolaWhileDongusuIleIlgiliSeylerYazdir() {
        System.out.println("-------------- WHILE --------------");
        //int y = 0;
        int y = 200;
        while (y < 100) {
            System.out.println("y küçük 100'den y değeri: " + y);
            y = y + 20; // değeri güncellemeyi unutursanız sonsuz döngüye girer
        }
    }

    public void konsolaDoWhileDongusuIleIlgiliSeylerYazdir() {
        System.out.println("-------------- DO-WHILE --------------");
        //int y = 0;
        int y = 200;
        do {
            System.out.println("y değeri: " + y);
            y = y + 20; // önemli bir adım
        } while (y < 100);
    }

    public void konsolaIcIceForKonusuIleIlgiliSeyleriYazdir() {
        System.out.println("--------------- İÇ İÇE FOR --------------");

        for (int i = 0; i < 4; i++) {
            System.out.println("i değeri: " + i);
            // 0.yı yaparken gel 3 kere şu işi yap
            // 1.yi yaparken gel 3 kere şu işi yap
            // 2.yi yaparken gel 3 kere şu işi yap
            // 3.yi yaparken gel 3 kere şu işi yap
            for (int j = 0; j < 3; j++) {
                System.out.println("satranç gibi: " + j);
            }
        }

        for (int i = 0; i < 400; i++) {
            if (i > 5) {
                break; // DÖNGÜYÜ KIRAR VE BİTİRİR
            }
            System.out.println("i değeri (break konusu): " + i);
        }

        for (int i = 0; i < 5; i++) {
            if (i == 2) {
                continue; // DÖNGÜDE BU ADIMI ATLAR
            }
            System.out.println("i değeri (continue konusu): " + i);
        }

        for (int i = 0; i < 2; i++) {
            // break;continue; -> i forunu etkiler
            for (int j = 0; j < 3; j++) {
                // break;continue; -> j forunu etkiler
                System.out.println("Değerler: [" + i + "][" + j + "]");
                // break;continue; -> j forunu etkiler
            }
            // break;continue; -> i forunu etkiler
        }
    }
}
