package tr.com.koncaholding.egitim2;

import tr.com.koncaholding.egitim2.degiskenkonusu.KonuDegiskenMetod;

/**
 * Bu sınıf bir eğitim sınıfıdır
 * @author Mahmut Tuncerovski
 */
public class AnaSinif {

    int rakamIlkDegisken = 90; // sdşkjfsdlkfjsd

    public static void main(String[] args) {

        System.out.println("HELLO WORLD - DERS 1");

        // EĞİTİM-1: YAZIM STİLİ
        /*
        CAMEL CASE
        Tüm hepsinde Türkçe karakter kullanılmaz
        Proje Adları: MehmetinProjeCalismasi (Büyük harfle başlar yenibir kelimeye kadare küçük harf yeni kelimenin ilk harfi büyük, alt tire gibi şeyler yok)
        Class(Sınıf) Adları: MehmetinSinifi
        Metod Adları: mehmetinSinifinaAitMethod (tek fark ilk harf de küçük yazılır)
        Değişken Adları: mehmetinSinifinaAitDegisken
        *Sabit Adları: MEHMETIN_SINIFI

        Paket Adları: com.testinium.projeadi.mantiksalpaket (komple küçük harf çünkü domain adını tersten yazıyoruz mesela: com.hepsiburada.mobilonyuz)

        (Yanlış örnekler: "mehmet'inProjesi" "mehmet'in Projesi" "Mehmetin_Projesi" "Mehmetin_projesi")
         */


        // EĞİTİM-2: YORUMLAR

        // satır bazlı yorum
        int degiskenFalan = 3; // devamıdır
        System.out.println("yorum işlemleri"); // bu bir comment'tir

        /*
        Birden fazla satırlık yorumlar için klullanılır
        mesela bu satır da yorum içinde
         */

        /**
         * JavaDOC için
         */

        // EĞİTİM-3 DEĞİŞKENLER
        System.out.println(45);
        int degisken = 56;
        System.out.println(degisken);

        // EĞİTİM-4 PRIMITIVE TYPES
        byte degiskenBytePrimitive;

        short degiskenYas = 32767;
        int degisken3 = 2147483647; // değer vermezsek otomatik olarak 0 kabul eder
        long degisken4 = 4598989989899999999l; // sonundaki l'ye dikkat

        float degisken6 = 5.4f; // küsüratlı sayıları tutar int'in küsüratlı versiyonudur
        double degisken7 = 34234234234.456456456d; // long'un küsüratlı sayılar için olanı

        char degisken8 = 'a'; // tek karakter: a, b, 4 ...

        boolean degisken9 = true; // false
        boolean degisken9a; // default olarak false alır

        System.out.println("Primitive değişken: " + degiskenYas);
        System.out.println(degisken6);

        // WRAPPER TYPES
        Byte degisken10;
        Short degisken11;
        Integer degisken12 = 2147483647;
        //short aaa = degisken12.shortValue();
        Integer degisken12a = new Integer(2147483647);
        Long degisken13;
        Float degisken14 = 13.5f;
        Float degisken14a = new Float(17.5);
        Double degisken15;
        Character degisken16c = 'a';
        String degisken16;
        String degisken16a = "gılgamış destanı";
        String degisken16b = new String("asdadadadas");
        Boolean degisken17;
        degisken17 = new Boolean(true);
        System.out.println("Değişken 17: " + degisken17);
        System.out.println("Wrapper Değişken Float: " + degisken14);

        // EĞİTİM-5 DEĞİŞKENLER VE METODLAR
        // ayrı sınıfa yazdık
        // EĞİTİM-8 Burada çağıracağız
        KonuDegiskenMetod degisken18 = new KonuDegiskenMetod(); // bu kötü
        KonuDegiskenMetod KonuDegiskenMetod = new KonuDegiskenMetod(); // bu kötü
        KonuDegiskenMetod konuDegiskenMetod = new KonuDegiskenMetod(); // bu güzel olanı

        int baskaSiniftakiDegisken = konuDegiskenMetod.degiskenRakam;
        System.out.println("KonuDegiskenMetod sınıfındaki degiskenRakam değişkeninin değeri: " + baskaSiniftakiDegisken);
        System.out.println("KonuDegiskenMetod sınıfındaki degiskenRakam değişkeninin değeri: " + konuDegiskenMetod.degiskenRakam);

        int carpmaMetoduSonucu = konuDegiskenMetod.carpmaIslemi(11,10);
        System.out.println("Çarpma Sonucu (11*10): " + carpmaMetoduSonucu);

        konuDegiskenMetod.konsolaYazdirMetodlari();

    }


}
