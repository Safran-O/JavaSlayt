package tr.com.koncaholding.egitim2.degiskenkonusu;

public class KonuDegiskenMetod {

    public int degiskenRakam = 67;

    // EĞİTİM-5 DEĞİŞKENLER
    // [erişim tipi] [veri tipi] [değişken adı] = [varsa değeri];
    // public/private/protected int/String/long/char/boolean degiskenAdiBurayaYazilir = deger;
    // erişim tipleri sınıf içinde tanımlanan değişkenler ve metodlar için kullanılır
    public String degiskenYazi1 = "sdfsdfçişsdgşifğ";
    public String degiskenYazi2 = new String("asdasdasdsad");
    public String degiskenYazi3;
    public Integer degiskenRakam1 = 63;
    public Integer degiskenRakam2 = new Integer(12);
    private Integer degiskenRakam3;


    // EĞİTİM-6 METODLAR
    // [erişim tipi] [dönüş tipi] [metod adı](varsa [degiskenler]) { ..... };
    // public/private/protected void/int/String/long/char/boolean metodAdiBurayaYazilir() { ............. };

    // void demek geri bir şey dönmeyecek
    public void helloYaz() {
        System.out.println("Hello");
        System.out.println(degiskenYazi2);
        // EĞİTİM-7 METOD içi DEĞİŞKENLER
        int yasToplami = 45 + 46 + 13; // sadece ve sadece bu metod içinde görülür ve kullanılabilir, o yüzden başına public/private yazılmaz çünkü anlamsız
        System.out.println("Aile yaş toplamı: " + yasToplami);
    }

    public int toplamaYap(){
        int a = 14;
        int b = 23;
        int sonuc = a+b;
        return sonuc;
    }

    public int carpmaIslemi(int birinciRakam, int ikinciRakam) {
        int sonuc = birinciRakam * ikinciRakam;
        return sonuc;
    }

    public void konsolaYazdirMetodlari(){
        helloYaz();
        int toplamaSonucu = toplamaYap();
        int carpmaSonucu = carpmaIslemi(45, 55);
        System.out.println("Toplama metodu çıktısı: " + toplamaSonucu);
        System.out.println("Çarpma metodu çıktısı: " + carpmaSonucu);
    }


}
