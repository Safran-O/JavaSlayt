package tr.com.koncaholding.egitim2.databaseislemleri;

import tr.com.koncaholding.egitim2.AnaSinif;

public class JavDocIcin {

    AnaSinif anaSinif;
}
