package com.topcuholding.bilgiteknolojileri.hatayaklama;

public class SifiraBolmeException extends Exception {

    @Override
    public String toString() {
        return "Sıfıra Bölmeye çalıştın dostum";
    }

    @Override
    public String getMessage() {
        return "Mesac bırakıyorum: Erkan enaktarlar koltuğun altında kalık beni ara";
    }
}
