package com.topcuholding.bilgiteknolojileri.enums;

public class Iphone12 {

    private String model;
    private String uretimYili;
    private String isletimSistemi;
    private MobileOS mobileIsletimSistemi;

    public Iphone12() {
    }

    public Iphone12(String model, String uretimYili, String isletimSistemi) {
        this.model = model;
        this.uretimYili = uretimYili;
        this.isletimSistemi = isletimSistemi;
    }

    public Iphone12(String model, String uretimYili, String isletimSistemi, MobileOS mobileIsletimSistemi) {
        this.model = model;
        this.uretimYili = uretimYili;
        this.isletimSistemi = isletimSistemi;
        this.mobileIsletimSistemi = mobileIsletimSistemi;
    }

    public MobileOS getMobileIsletimSistemi() {
        return mobileIsletimSistemi;
    }

    public void setMobileIsletimSistemi(MobileOS mobileIsletimSistemi) {
        this.mobileIsletimSistemi = mobileIsletimSistemi;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getUretimYili() {
        return uretimYili;
    }

    public void setUretimYili(String uretimYili) {
        this.uretimYili = uretimYili;
    }

    public String getIsletimSistemi() {
        return isletimSistemi;
    }

    public void setIsletimSistemi(String isletimSistemi) {
        this.isletimSistemi = isletimSistemi;
    }
}
