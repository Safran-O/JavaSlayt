package com.topcuholding.bilgiteknolojileri.enums;

public class GalaxyS21 {

    private String model;
    private String uretimYili;
    private String isletimSistemi = "ANDROID";
    private MobileOS mobileIsletimSistemi;
    private Iphone12 nullAlmakIcinDegisken;

    public GalaxyS21() {
    }

    public GalaxyS21(String model, String uretimYili, String isletimSistemi) {
        this.model = model;
        this.uretimYili = uretimYili;
        this.isletimSistemi = isletimSistemi;
    }

    public GalaxyS21(String model, String uretimYili, String isletimSistemi, MobileOS mobileIsletimSistemi) {
        this.model = model;
        this.uretimYili = uretimYili;
        this.isletimSistemi = isletimSistemi;
        this.mobileIsletimSistemi = mobileIsletimSistemi;
    }

    public MobileOS getMobileIsletimSistemi() {
        return mobileIsletimSistemi;
    }

    public void setMobileIsletimSistemi(MobileOS mobileIsletimSistemi) {
        this.mobileIsletimSistemi = mobileIsletimSistemi;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getUretimYili() {
        return uretimYili;
    }

    public void setUretimYili(String uretimYili) {
        this.uretimYili = uretimYili;
    }

    public String getIsletimSistemi() {
        return isletimSistemi;
    }

    public void setIsletimSistemi(String isletimSistemi) {
        this.isletimSistemi = isletimSistemi;
    }

    public Iphone12 getNullAlmakIcinDegisken() {
        return nullAlmakIcinDegisken;
    }

    public void setNullAlmakIcinDegisken(Iphone12 nullAlmakIcinDegisken) {
        this.nullAlmakIcinDegisken = nullAlmakIcinDegisken;
    }
}
