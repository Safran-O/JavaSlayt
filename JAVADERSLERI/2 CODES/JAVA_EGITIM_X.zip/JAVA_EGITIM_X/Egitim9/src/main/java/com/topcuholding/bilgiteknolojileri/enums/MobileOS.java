package com.topcuholding.bilgiteknolojileri.enums;

public enum MobileOS {

    IOS,
    ANDROID,
    HUAWEI_OS,
    SYMBIAN;

}
