package com.topcuholding.bilgiteknolojileri;

import com.topcuholding.bilgiteknolojileri.enums.GalaxyS21;
import com.topcuholding.bilgiteknolojileri.enums.Iphone12;
import com.topcuholding.bilgiteknolojileri.enums.MobileOS;
import com.topcuholding.bilgiteknolojileri.hatayaklama.HataYakalamaOrnekler;
import com.topcuholding.bilgiteknolojileri.hatayaklama.SifiraBolmeException;

public class AnaSinif {

    public static void main(String[] args) {

        System.out.println("HALLO DAS IST WORLT");

        System.out.println("---------------------");
        System.out.println("ENUMS");
        System.out.println("---------------------");

        Iphone12 iphone12Ali = new Iphone12("Beyaz", "2021", "ios");
        Iphone12 iphone12Furkan = new Iphone12("Mor", "2021", "IOS");
        Iphone12 iphone12Ayse = new Iphone12("Mor", "2021", "iOS");
        GalaxyS21 galaxyS21Veli = new GalaxyS21("Yeşil", "2020", "android");
        GalaxyS21 galaxyS21Mahmut = new GalaxyS21("Siyah", "2021", "Android");
        GalaxyS21 galaxyS21Murtaza = new GalaxyS21("Siyah", "2021", "ANDROID");

        System.out.println("Ali telefonun işletim sistemi: " + iphone12Ali.getIsletimSistemi());
        System.out.println("Furkan telefonun işletim sistemi: " + iphone12Furkan.getIsletimSistemi());
        System.out.println("Ayşe telefonun işletim sistemi: " + iphone12Ayse.getIsletimSistemi());

        if (iphone12Ali.getIsletimSistemi().equals("IOS")) {
            System.out.println("Ali IOS telefon kullanıyor");
        } else {
            System.out.println("Ali Android telefon kullanıyor");
        }

        // Ben eğer yukarıdaki gibi if koşullarında kullanacağım ve genel olarak herkeste aynı isimle anılsın istiyorsam
        // Normal değişken değil de ENUM olarak tanımlarım ve sorunumu çözerim
        System.out.println("Enum sonrası --------------------");

        //iphone12Ali.setIsletimSistemi("ios");
        iphone12Ali.setMobileIsletimSistemi(MobileOS.IOS);
        iphone12Furkan.setMobileIsletimSistemi(MobileOS.IOS);
        iphone12Ayse.setMobileIsletimSistemi(MobileOS.IOS);
        galaxyS21Veli.setMobileIsletimSistemi(MobileOS.ANDROID);
        galaxyS21Mahmut.setMobileIsletimSistemi(MobileOS.ANDROID);
        galaxyS21Murtaza.setMobileIsletimSistemi(MobileOS.ANDROID);
        GalaxyS21 galaxyS21Muzaffer = new GalaxyS21("Mor", "2021", "anDORIds", MobileOS.ANDROID);

        if (iphone12Ali.getMobileIsletimSistemi().equals(MobileOS.IOS)) {
            System.out.println("Ali ios kullanıyor");
        } else if (iphone12Ali.getMobileIsletimSistemi().equals(MobileOS.ANDROID)) {
            System.out.println("Ali android kullanıyor");
        } else {
            System.out.println("Ali symbian kullanıyor");
        }

        switch (galaxyS21Mahmut.getMobileIsletimSistemi()) {
            case ANDROID:
                System.out.println("Mahmut Android kullanıyor");
                break;
            case IOS:
                System.out.println("Mahmut Iphone kullanıyor");
                break;
            case SYMBIAN:
                System.out.println("Mahmut Nokia kullanıyor");
                break;
            case HUAWEI_OS:
                System.out.println("Mahmut Huawei kullanıyor");
                break;
            default:
                System.out.println("Mahmut tuşlu tel kullanıyor");
                break;
        }

        // enum'ın string hali:
        System.out.println("Alinin işletim sistemi: " + iphone12Ali.getMobileIsletimSistemi());
        System.out.println("Alinin işletim sistemi: " + MobileOS.IOS);


        System.out.println("---------------------");
        System.out.println("EXCEPTION HANDLING");
        System.out.println("---------------------");

        // Yazımsal hata değil de mantıksal hata olduğu zaman program çöker patlar çatlar kıvranır göçer ama hangi göçer tabiki Ferhat Göçer

        // Compiler Time Exception -> yazım esnasıdaki hatadan dolayı derleyememesi
        //int a = "sdfdsfds";
        // RunTime Exception -> yazımda sorun yok ama program çalışırken patlayabilir
        //int b = 9 / 0;
        //System.out.println("B değeri: " + b);

        try {
            int b = 9 / 0;
            int c = b * 5;
            System.out.println("sonuc: " + c);
            //System.out.println("işlem bitti");
        } catch (Exception e) {
            System.out.println("Hatasız kul olmaz: " + e);
            //System.out.println("işlem bitti");
        } finally {
            System.out.println("işlem bitti");
        }
        System.out.println("try catch sonrası");

        System.out.println("------");
        HataYakalamaOrnekler hataYakalamaOrnekler = new HataYakalamaOrnekler();
        hataYakalamaOrnekler.hataKonuAnlatimi();
        hataYakalamaOrnekler.hataKonuAnlatimi1();
        hataYakalamaOrnekler.hataKonuAnlatimi2();
        hataYakalamaOrnekler.hataKonuAnlatimi3();
        hataYakalamaOrnekler.hataKonuAnlatimi4();
        hataYakalamaOrnekler.hataKonuAnlatimi5();
        hataYakalamaOrnekler.hataKonuAnlatimi6();
        try {
            System.out.println("---- kendi exception sınıfımız: ----");
            hataYakalamaOrnekler.hataKonuAnlatimi7();
        } catch (SifiraBolmeException e) {
            System.out.println("HATA: " + e);
            System.out.println("HATA: " + e.getMessage());
            System.out.println("HATA: " + e.getLocalizedMessage());
        }



    }

}
