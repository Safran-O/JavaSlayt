package com.topcuholding.bilgiteknolojileri.hatayaklama;

import com.topcuholding.bilgiteknolojileri.enums.GalaxyS21;

public class HataYakalamaOrnekler {

    public void hataKonuAnlatimi() {
        try {
            // Metoda ait tüm kodlar burada olacak
            // Metoda ait tüm kodlar burada olacak
            // Metoda ait tüm kodlar burada olacak
            // Metoda ait tüm kodlar burada olacak
            System.out.println("Metoda ait tüm kodlar burada olacak");
            // Metoda ait tüm kodlar burada olacak
            // Metoda ait tüm kodlar burada olacak
            // Metoda ait tüm kodlar burada olacak
            // Metoda ait tüm kodlar burada olacak
        } catch (Exception e) {
            System.out.println("Hata: " + e);
        }
    }

    public void hataKonuAnlatimi1() {
        try {

            int[] rakamArray = {35, 66, 89};
            System.out.println("dizinin 20.elemanı: " + rakamArray[19]);
            System.out.println("danke schön");

        } catch (Exception e) {
            System.out.println("Hata hataKonuAnlatimi1: " + e);
        }
    }

    public void hataKonuAnlatimi2() {
        try {

            GalaxyS21 galaxyS21 = new GalaxyS21();
            String model = galaxyS21.getNullAlmakIcinDegisken().getModel();
            System.out.println("Model: " + model);

        } catch (Exception e) {
            System.out.println("Hata hataKonuAnlatimi2: " + e);
        }
    }

    public void hataKonuAnlatimi3() {
        try {

            /*
            int x = 9 / 0;

            int[] rakamArray = {35, 66, 89};
            System.out.println("dizinin 20.elemanı: " + rakamArray[19]);

            GalaxyS21 galaxyS21 = new GalaxyS21();
            String model = galaxyS21.getNullAlmakIcinDegisken().getModel();
            System.out.println("Model: " + model);

             */

            Integer.parseInt("9");
            Integer.parseInt("aaa");
            Integer.parseInt("8");

        } catch (ArithmeticException e) {
            System.out.println("Bölme hatası : " + e);
        } catch (NullPointerException e) {
            System.out.println("New yapmamadan dolayı boş bırakma hatası : " + e);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Dizi boyutu dışına çıkma hatası : " + e);
        } catch (Exception e) {
            System.out.println("Yahu işte yapmışsın bir hata: " + e);
        }
    }

    /**
     * cathc içinde tekrar try ctch zorunlu olmadıkça kullanılmaz
     */
    public void hataKonuAnlatimi4() {
        try {

            int[] rakamArray = {35, 66, 89};
            System.out.println("dizinin 20.elemanı: " + rakamArray[19]);

        } catch (Exception e) {
            System.out.println("Hata hataKonuAnlatimi4: " + e);
            try {
                int[] rakamArray = {35, 66, 89};
                System.out.println("dizinin 2.elemanı: " + rakamArray[1]);
            } catch (Exception e2) {
                System.out.println("Hata hataKonuAnlatimi4 2. hata: " + e2);
            }
        }
    }

    public void hataKonuAnlatimi5() {
        try {
            // veritabanına connection açıldı

            int[] rakamArray = {35, 66, 89};
            System.out.println("dizinin 20.elemanı: " + rakamArray[19]);
            //System.out.println("eni sonu burayı yapar");
        } catch (Exception e) {
            System.out.println("Hata hataKonuAnlatimi5: " + e);
            //System.out.println("eni sonu burayı yapar");
        } finally { // try'da olsa catch'e de düşse eni sonu bu bloktakileri yapar
            // veritabanı ile olan bağlantıyı kapat
            System.out.println("eni sonu burayı yapar");
        }
    }


    public void hataKonuAnlatimi6() {
        try {
            hataKonuAnlatimi6altMetod();
            System.out.println("okito nakamura");
        } catch (Exception e) {
            System.out.println("Hata: " + e);
        }
    }

    // throws ile metodun hataları yönlendirdiğini söyleyip, bu metodu kullanan kişileri try-catch kullanmaya zorlamış oluyoruz
    public void hataKonuAnlatimi6altMetod() throws Exception{
        try {
            int x = 9 / 0;
        } catch (Exception e) {
            // throw ile hatayı bu metodu kullanana gönderiyoruz
            throw e;
        }
    }

    public void hataKonuAnlatimi7() throws SifiraBolmeException {
        try {
            int x = 9 / 0;
        } catch (Exception e) {
            throw new SifiraBolmeException();
        }
    }

}
