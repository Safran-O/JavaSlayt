package com.esgisoftware;

public class AnaSinif {

    public static void main(String[] args) {

        System.out.println("EĞİTİM-9 OPERATÖRLER");

        System.out.println("-----------------------");
        System.out.println("ARİTMETİK OPERATORLER");
        System.out.println("-----------------------");

        int x = 19;
        int y = 6;

        int sonucToplama = x + y;
        int sonucCikarma = x - y;
        int sonucCarpma = x * y;
        int sonucBolme = x / y; // 1.998 bile olsa direk 1 yazar
        int sonucMod = x % y;

        System.out.println("Toplama Sonucu: " + sonucToplama); // buradaki + işareti yazıya ekleme yapıyorum anlamında
        System.out.println("Çıkarma Sonucu: " + sonucCikarma);
        System.out.println("Çarpma Sonucu: " + sonucCarpma);
        System.out.println("Bölme Sonucu: " + sonucBolme);
        System.out.println("Mod Sonucu: " + sonucMod);

        float a = 5.0f;
        float b = 2.0f;
        float sonucBolmeAB = a / b;
        System.out.println("Bölme Sonucu1: " + sonucBolmeAB);

        int c = 5;
        int d = 2;
        float sonucIntBolme = c / d; // 5/2 -> 2 -> 2.0
        System.out.println("Bölme Sonucu2: " + sonucIntBolme);
        // DİKKAT bunu kullanmayın: float = int / int yapmayın

        float sonucBolmeXY2 = (float) c / d; // (float) type casting
        System.out.println("Bölme Sonucu3: " + sonucBolmeXY2);

        System.out.println("-----------------------");
        int sayi2 = 10;
        System.out.println("Sayi2 : " + sayi2);
        sayi2 = sayi2 + 5;
        System.out.println("Sayi2 : " + sayi2);
        sayi2 = sayi2 + 5;
        System.out.println("Sayi2 : " + sayi2);

        sayi2 += 5; // sayi2 = sayi2 + 5;
        System.out.println("+= ile Beş artmış: " + sayi2);
        sayi2 -= 5;
        System.out.println("-= ile Beş azalmış: " + sayi2);
        sayi2 *= 5;
        System.out.println("*= ile Beş katı: " + sayi2);
        sayi2 /= 5;
        System.out.println("/= ile Beşte biri: " + sayi2);

        System.out.println("-----------------------");
        int sayi1 = 10;
        //sayi1 = sayi1 + 1;
        //sayi1 = sayi1 - 1;

        sayi1++; // ++ işareti her zaman 1 arttır demektir
        System.out.println("++ ile Bir artmış: " + sayi1);
        sayi1--;
        System.out.println("-- ile Bir azalmış: " + sayi1);

        sayi1 = 20;
        ++sayi1;
        System.out.println("++ ile Bir artmış: " + sayi1);
        --sayi1;
        System.out.println("-- ile Bir azalmış: " + sayi1);

        sayi1 = 30;
        System.out.println("++ sonda: " + (sayi1++));
        System.out.println("sayının son duurumu: " + sayi1);

        sayi1 = 40;
        System.out.println("++ başta: " + (++sayi1));
        System.out.println("sayının son duurumu: " + sayi1);

        System.out.println("-----------------------");
        int sonuc = 5 + 9 * (3 - 6) / 2;
        int sonuc2 = 5 + 9 * 3 - 6 / 2;
        System.out.println("Sonuç: " + sonuc);
        System.out.println("Sonuç2: " + sonuc2);


        System.out.println("-----------------------");
        System.out.println("İLİŞKİSEL OPERATORLER");
        System.out.println("-----------------------");

        boolean boolDeger1 = false;
        System.out.println("Boolean değer: " + boolDeger1);

        boolDeger1 = (5 > 3);
        System.out.println("Büyük kontrol sonucu: " + boolDeger1);
        boolDeger1 = (3 < 3); // false küçük müdür?
        boolDeger1 = (3 <= 3); // true büyük eşit midir?
        boolDeger1 = (5 == 5); // 5 5'e eşit mi = true // not sadece eşittir işareti atama yapar
        boolDeger1 = (3 != 5); // true eşit değil midir?
        boolDeger1 = (5 != 5); // false eşit değil midir?
        System.out.println("Eşit Değilmi karşılaştırması sonucu: " + boolDeger1);


        System.out.println("-----------------------");
        System.out.println("MANTIKSAL OPERATORLER");
        System.out.println("-----------------------");
        boolean boolDeger2;
        int x1 = 5;
        int y1 = 3;
        int z1 = 9;

        boolDeger2 = (x1 > y1) && (y1 < z1); // true VE true
        System.out.println("AND sonucu: " + boolDeger2);

        // && (VE) operatörü tüm şartları sağlıyorsa true gelir aksi taktirde false olur
        boolDeger2 = (5 > 3) && (6 > 2); // TRUE AND TRUE = TRUE
        boolDeger2 = (5 < 3) && (6 > 2); // FALSE AND TRUE = FALSE;
        System.out.println("AND sonucu: " + boolDeger2);
        boolDeger2 = (1 < 3) && (6 > 2) && (6 < 7) && (4 > 13) && (5 > 1); // (4 > 13)'den dolayı false geldi
        System.out.println("AND sonucu: " + boolDeger2);
        // TRUE && TRUE && TRUE && TRUE && TRUE ----> TRUE
        // TRUE && FALSE && TRUE && TRUE && TRUE ----> FALSE

        // || (VEYA) operatörü şartlardan herhangi birisini sağlıyorsa true gelir aksi taktirde false olur
        boolDeger2 = (5 > 10) || (6 > 3); // FALSE OR TRUE = TRUE;
        System.out.println("OR sonucu: " + boolDeger2);
        boolDeger2 = (5 > 10) || (1 > 3); // FALSE OR FALSE = FALSE;
        System.out.println("OR sonucu: " + boolDeger2);
        // FALSE || FALSE || TRUE || FALSE || FALSE ----> TRUE
        // FALSE || FALSE || FALSE || FALSE || FALSE ----> FALSE

        // ! operatörü tam terse çevirir (true -> false)
        boolean kayitYapildiMi = true;
        boolean kayitYapmakGerekliMi = !kayitYapildiMi;
        System.out.println("Kayıt Yapmaya gerek Var mı: " + kayitYapmakGerekliMi);



        System.out.println("-----------------------");
        System.out.println("KARAKTER İŞLEMLERİ");
        System.out.println("-----------------------");
        int rakam1 = 5;
        int rakam2 = 10;
        int sonucRakamTopla = rakam1 + rakam2; // bu artı işareti toplama yaptı
        System.out.println("Toplama sonuc: " + sonucRakamTopla); // bu artı işareti ise yazıya ekleme yaptı

        String yazi1 = "Mahmut";
        String yazi2 = "Tuncer";
        String sonucYazi = yazi1 + yazi2; // iki stringi birbirine ekledi
        System.out.println("Yazı sonucu: " + sonucYazi);

        // bir stringten sonra + işareti gelirse artık tüm +'lar sadece yazıya ekleme yapar toplama yapmaz

        String yazi11 = "3";
        String yazi22 = "4";
        String sonucYazi11 = yazi11 + yazi22; // 34
        System.out.println("Yazı sonucu: " + sonucYazi11);

        int rakam3 = 10;
        int rakam4 = 50;
        System.out.println("Sonuç: " + (rakam3 + rakam4)); // Sonuç: 60
        System.out.println("Sonuç: " + rakam3 + rakam4); // Sonuç: 1050

        // string gördükten sonra artık tüm artılar karakter ekeleme olur toplama olmaz.
        // Not: parantezler kendi içinde değerlendirilir
        System.out.println(rakam3 + rakam4 + "-AAAAAAAA-" + rakam3 + rakam4); // 60-AAAAAAAA-1050
        System.out.println("" + rakam3 + rakam4 + "-AAAAAAAA-" + rakam3 + rakam4); // 1050-AAAAAAAA-1050
        System.out.println("" + rakam3 + rakam4 + "-AAAAAAAA-" + (rakam3 + rakam4)); // 1050-AAAAAAAA-60

    }
}
