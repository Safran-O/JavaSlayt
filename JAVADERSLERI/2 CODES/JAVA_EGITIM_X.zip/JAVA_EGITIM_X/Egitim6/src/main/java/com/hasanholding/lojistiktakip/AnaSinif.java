package com.hasanholding.lojistiktakip;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AnaSinif {

    public static void main(String[] args) {

        System.out.println("HELLO WORLD");

        System.out.println("-----------------");
        System.out.println("ARRAYS & COLLECTIONS");
        System.out.println("-----------------");
        System.out.println("-----------------");

        System.out.println("-----------------");
        System.out.println("ARRAYS");
        System.out.println("-----------------");

        int x1 = 10;
        int x2 = 7;
        int x3 = 45;
        int x99 = 45;
        // ....

        // Dizi uzunlukları sabittir
        int[] xDizisi = new int[10]; // 10 tane veri tutabilen dizi yani 10 elemanlı dizi
        xDizisi[0] = 50; // 1. elemanına 50 değerini verdik
        xDizisi[1] = 30; // 2. elemanına 30 değerini verdik
        //....
        xDizisi[9] = 60; // 10. eleman
        //xDizisi[15] = 50; // 16. elemanı olmadığı için patlar uygulama çöker
        //System.out.println("buradan aşağısı çalışmaz");

        int[] yDizisi = {34, 63, 45, 66}; // 4 elemanlı bir dizi oldu ve değerler baştan verilmiş oldu

        System.out.println("X Dizisi 2. elemanı: " + xDizisi[1]);
        System.out.println("Y Dizisi 3. elemanı: " + yDizisi[2]);
        //System.out.println("Y Dizisi 99. elemanı: " + yDizisi[98]);

        String[] halayDizisi = {"Yasir Konca", "Melisa Özcan", "Hasancan İşbeceren", "Göksu Kaya", "Gizem Kalay", "Nurullah Topçu", "Berkcan Teber", "Mahmut Tuncer"};
        System.out.println("Halaydaki kişi sayısı: " + halayDizisi.length);
        //for (int i = 0; i < 8; i++) {
        for (int i = 0; i < halayDizisi.length; i++) {
            System.out.println("Halay Elemanı: " + halayDizisi[i]);
        }

        // DİZİLERDE VE COLLECTIONS'LARDA KULLANILAN FOR YÖNTEMİ ve EN ÇOK KULLANILANI BU YÖNTEMDİR
        // for ([dizinin tipi] [herBirElemaninaVerilecekDegiskenAdi] : [dizi])
        for (String halayUyesi : halayDizisi) {
            System.out.println("Halay Üyesi: " + halayUyesi);
        }

        // INTELLIJ'ye özel kısa yol:
        //halayDizisi.for
        //halayDizisi.fori

        // İKİ BOYUTLU DİZİLER
        String[][] ikiBoyutlu = new String[2][4];
        /*
        "A" "B" "C" "D"
        "E" "F" "G" "H"
        */
        ikiBoyutlu[0][0] = "A";
        ikiBoyutlu[0][1] = "B";
        ikiBoyutlu[0][2] = "C";
        ikiBoyutlu[0][3] = "D";
        ikiBoyutlu[1][0] = "E";
        ikiBoyutlu[1][1] = "F";
        ikiBoyutlu[1][2] = "G";
        ikiBoyutlu[1][3] = "H";
        System.out.println("İki Boyutlu Döngünün Elemanı: " + ikiBoyutlu[1][2]);

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.println("İki boyutlu dizinin tüm elemanları: " + ikiBoyutlu[i][j]);
            }
        }

        if (args.length > 0) {
            System.out.println("İlk Argüman: " + args[0]);
        } else {
            System.out.println("Argümansız kalkmış");
        }

        // DİZİLERDE SIRALAMA
        int[] zArray = {65, 95, 26, 32, 45, 678, 98};
        for (int z : zArray) {
            System.out.println("Z değeri: " + z);
        }

        System.out.println("Sıralama yapıyoruz");
        Arrays.sort(zArray); // stringleri alfabetik, sayıları değerlerine göre küçükten büyüğe sıralar

        for (int z : zArray) {
            System.out.println("Z değeri: " + z);
        }

        // String gibi int gibi Ogrenci sınıfından da dizi oluşturabilirsiniz
        Ogrenci[] ogrArray = new Ogrenci[5];
        Ogrenci ogr1 = new Ogrenci();
        ogr1.adSoyad = "Mahmut asdad";
        ogr1.yas = 14;
        ogrArray[0] = ogr1;

        System.out.println("-----------------");
        System.out.println("COLLECTION - LIST - ARRAYLIST");
        System.out.println("-----------------");
        /*
        String[] ogrenciler = new String[1000];
        ogrenciler[0] = "Ali Çizmaz";
        //ogrenciler[1000] = "Falan Filan";
        //String[] ogrenciler = new String[10000000];
        //ogrenciler[1001] = new String();
        */

        String[] sehirlerArray = new String[5];
        sehirlerArray[0] = "Istanbul";

        // poşet gibi olan herhangi bir sınıırı olmayan bir dizi olsa ne güzel olurdu
        //List<String> sehirlerList = new LinkedList<>(); // poşet gibi sıralamasının bir önemi olan boyut sorunu olmayan dizi çeşidi
        List<String> sehirlerList = new ArrayList<>(); // poşet gibi sıralamasının bir önemi olmayan boyut sorunu olmayan dizi çeşidi
        sehirlerList.add("İstanbul");
        sehirlerList.add("Kayseri");
        sehirlerList.add("Zonguldak");
        sehirlerList.add("Tekirdağ");
        sehirlerList.add("Manisa");
        sehirlerList.add("Ayvalık");
        sehirlerList.add("Trabzon");
        sehirlerList.add("Kırşehir");
        sehirlerList.add("Kırşehir");
        sehirlerList.add("Kırşehir");
        sehirlerList.add("Urfa");
        sehirlerList.add("Urfa");

        // LinkedList değil de ArrayList kullandığımız için sıralamanın bir garantisi yoktur.
        System.out.println("İlk Şehir: " + sehirlerList.get(0)); // bu güzel bir kullanım değildir

        for (int i = 0; i < sehirlerList.size(); i++) {
            System.out.println("Şehir: " + sehirlerList.get(i));
        }
        for (String sehir : sehirlerList) {
            System.out.println("Şehir (güzel for): " + sehir);
        }

        sehirlerList.remove("İstanbul");
        for (String sehir : sehirlerList) {
            System.out.println("Şehir (remove yaptık): " + sehir);
        }

        sehirlerList.remove("Kırşehir");
        for (String sehir : sehirlerList) {
            System.out.println("Şehir (Kırşehir gitti): " + sehir);
        }

        if (sehirlerList.contains("Mardin")) {
            System.out.println("Evet Mardin şehri listede var");
        } else if (sehirlerList.contains("Kırşehir")) {
            System.out.println("Evet Kırşehir şehri listede var");
        } else {
            System.out.println("Listede Kırşehir ve Mardin yok");
        }


        Ogrenci ogr2 = new Ogrenci();
        ogr2.adSoyad = "Ahmet Falan";
        ogr2.yas = 56;

        Ogrenci ogr3 = new Ogrenci();
        ogr3.adSoyad = "Tuğba Filan";
        ogr3.yas = 89;

        List<Ogrenci> ogrenciList = new ArrayList<>();
        ogrenciList.add(ogr1);
        ogrenciList.add(ogr1);
        ogrenciList.add(ogr2);
        ogrenciList.add(ogr2);
        ogrenciList.add(ogr2);
        ogrenciList.add(ogr3);
        ogrenciList.add(ogr3);
        ogrenciList.add(ogr3);

        for (Ogrenci ogrenci : ogrenciList) {
            System.out.println("Öğrenci: " + ogrenci.adSoyad + " - yaş: " + ogrenci.yas);
        }

        if (ogrenciList.contains(ogr1)) {
            System.out.println("Öğrenci1 listede var");
        } else {
            System.out.println("Öğrenci1 listede yok");
        }

        Ogrenci ogr99 = new Ogrenci(); // listeye eklemeyeceğim
        ogr99.adSoyad = "Murtaza adasd";

        if (ogrenciList.contains(ogr99)) {
            System.out.println("Öğrenci99 listede var");
        } else {
            System.out.println("Öğrenci99 listede yok");
        }

        int kacAhmetVar=0;
        for (Ogrenci o : ogrenciList) {
            if(o.adSoyad.equals("Ahmet Falan")) {
                kacAhmetVar++;
            }
        }
        System.out.println("Listede toplamda " + kacAhmetVar + " tane Ahmet Falan isminde öğrenci var");

        ogrenciList.remove(ogr2);
        for (Ogrenci ogrenci : ogrenciList) {
            System.out.println("Sildikten sonra öğrenci: " + ogrenci.adSoyad + " - yaş: " + ogrenci.yas);
        }

        //ogrenciList.remove(ogr3);
        //ogrenciList.remove(ogr3);
        //ogrenciList.remove(ogr3);
        /*
        // HATALI YÖNTEM
        for (Ogrenci ogrenci : ogrenciList) {
            ogrenciList.remove(ogr3);
        } // Exception in thread "main" java.util.ConcurrentModificationException
         */

        // 1. YÖNTEM
        /*while (ogrenciList.contains(ogr3)) {
            ogrenciList.remove(ogr3);
        }*/

        // 2.YÖNTEM
        List<Ogrenci> silinecekOgrenciler = new ArrayList<>();
        for (Ogrenci o : ogrenciList) {
            if(o == ogr3) {
                silinecekOgrenciler.add(o);
            }
        }
        ogrenciList.removeAll(silinecekOgrenciler);

        for (Ogrenci ogrenci : ogrenciList) {
            System.out.println("OGR3 silindikten sonra öğrenci: " + ogrenci.adSoyad + " - yaş: " + ogrenci.yas);
        }


        System.out.println("-----------------");
        System.out.println("COLLECTION - SET - HASHSET");
        System.out.println("-----------------");
        //Set<String> sehirlerSet = new LinkedHashSet<>();
        Set<String> sehirlerSet = new HashSet<>();
        sehirlerSet.add("Kayseri");
        sehirlerSet.add("Kayseri"); // 2.yi hesaba katmaz
        sehirlerSet.add("Kayseri"); // 3.yü hesaba katmaz
        sehirlerSet.add("Manisa");
        sehirlerSet.add("Manisa");
        sehirlerSet.add("Manisa");
        sehirlerSet.add("Kırşehir");
        sehirlerSet.add("Kırşehir");
        sehirlerSet.add("Kırşehir");
        sehirlerSet.add("Urfa");
        sehirlerSet.add("Urfa");

        System.out.println("SehirlerSet size: " + sehirlerSet.size());

        // LIST'ten farkı aynı objeden bir tane alır
        for (String sehir : sehirlerSet) {
            System.out.println("Şehir: " + sehir);
        }

        // contains,
        // size,
        // remove,
        // vs.
        // bunda da var

        Set<Ogrenci> ogrenciSet = new HashSet<>();
        ogrenciSet.add(ogr1);
        ogrenciSet.add(ogr1);
        ogrenciSet.add(ogr1);
        ogrenciSet.add(ogr2);
        ogrenciSet.add(ogr2);
        ogrenciSet.add(ogr3);
        ogrenciSet.add(ogr3);
        ogrenciSet.add(ogr3);

        for (Ogrenci ogrenci : ogrenciSet) {
            System.out.println("Öğrenciler: " + ogrenci.adSoyad);
        }


        System.out.println("-----------------");
        System.out.println("COLLECTION - MAP - HASHMAP");
        System.out.println("-----------------");
        // LIST ve SET aynıdır tek fark SET'in verileri unique tutması
        // Ama MAP biraz daha farklı, map dediğimiz aynı db'deki tutma gibi oluyor

        //Map<Integer, String> sehirlerMap = new LinkedHashMap<>();
        Map<Integer, String> sehirlerMap = new HashMap<>();
        // Map<Key, Value> diye geçer ve Key'e örnek: TcKimlikNo veya Plaka
        sehirlerMap.put(34, "Istanbul");
        sehirlerMap.put(1, "Adana");
        sehirlerMap.put(50, "Nevşehir");
        sehirlerMap.put(26, "Eskişehir");
        sehirlerMap.put(33, "Mersin");
        sehirlerMap.put(43, "Kütahya");
        sehirlerMap.put(47, "Mardnnnnnnnnnnnn");
        sehirlerMap.put(47, "Mardin"); // aynı anahtara bir daha veri yollarsam bir önceki verisini ezer
        sehirlerMap.put(99, "İstanbul");

        System.out.println("Şehir sayısı: " + sehirlerMap.size());

        sehirlerMap.remove(34);

        if (sehirlerMap.containsKey(50)) {
            System.out.println("Plakası 50 olan şehir var");
        }
        if (sehirlerMap.containsValue("Mardin")) {
            System.out.println("Mardin isimli bir şehir var");
        }

        for (Map.Entry sehirKeyValue : sehirlerMap.entrySet()) {
            System.out.println("Şehir Key: " + sehirKeyValue.getKey() + " Value: " + sehirKeyValue.getValue());
        }

        Map<String, String> dersMap = new HashMap<>();
        dersMap.put("MAT-101", "Matematik 101");
        dersMap.put("CAL-101", "Calculus 101");
        dersMap.put("BIL-101", "Bilgisayar Dersi 101");
        dersMap.put("BIL-101", "Yazılıma Giriş");

        for (Map.Entry dersEntry : dersMap.entrySet()) {
            System.out.println("Ders Key: " + dersEntry.getKey() + " Value: " + dersEntry.getValue());
        }


        System.out.println("-----------------");
        System.out.println("COLLECTION EXTRAS - ITERATOR");
        System.out.println("-----------------");
        // List, Set ve Map için yani tüm Collenction'lar için kullanılabilir

        Iterator<String> sehirlerListIteratoru = sehirlerList.iterator();
        while (sehirlerListIteratoru.hasNext()) {
            String sehir = sehirlerListIteratoru.next();
            System.out.println("Şehir (list iterator): " + sehir);
        }

        Iterator<String> sehirlerSetItr = sehirlerSet.iterator();
        while (sehirlerSetItr.hasNext()) {
            String sehir = sehirlerSetItr.next();
            System.out.println("Şehir (set iterator): " + sehir);
        }

        Iterator sehirlerMapItr = sehirlerMap.entrySet().iterator();
        while (sehirlerMapItr.hasNext()) {
            Map.Entry sehirKeyValue = (Map.Entry) sehirlerMapItr.next();
            System.out.println("Şehir (map iterator): " + sehirKeyValue.getValue());
        }

    }
}
