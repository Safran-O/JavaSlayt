package com.hasanholding.lojistiktakip;

public class Ogrenci {

    public String adSoyad;
    public int yas;
}
