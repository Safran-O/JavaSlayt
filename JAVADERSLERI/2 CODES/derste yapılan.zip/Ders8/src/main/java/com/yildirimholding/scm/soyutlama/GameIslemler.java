package com.yildirimholding.scm.soyutlama;

public interface GameIslemler {

    // [dönüş tipi] [metod adı] ([varsa parametreler])

    String oyunIndir();

    void oyunOyna(String oyunAdi);


}
