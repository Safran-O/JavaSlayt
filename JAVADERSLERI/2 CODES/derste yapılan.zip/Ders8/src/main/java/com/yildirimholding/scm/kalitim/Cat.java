package com.yildirimholding.scm.kalitim;

public class Cat {

    private String adi;
    private String cinsi;
    private int yasi;
    private String renk;
    private int tirmalamaKuvveti;
    private int maxDusmeYukseklik;

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public String getCinsi() {
        return cinsi;
    }

    public void setCinsi(String cinsi) {
        this.cinsi = cinsi;
    }

    public int getYasi() {
        return yasi;
    }

    public void setYasi(int yasi) {
        this.yasi = yasi;
    }

    public String getRenk() {
        return renk;
    }

    public void setRenk(String renk) {
        this.renk = renk;
    }

    public int getTirmalamaKuvveti() {
        return tirmalamaKuvveti;
    }

    public void setTirmalamaKuvveti(int tirmalamaKuvveti) {
        this.tirmalamaKuvveti = tirmalamaKuvveti;
    }

    public int getMaxDusmeYukseklik() {
        return maxDusmeYukseklik;
    }

    public void setMaxDusmeYukseklik(int maxDusmeYukseklik) {
        this.maxDusmeYukseklik = maxDusmeYukseklik;
    }
}
