package com.yildirimholding.scm.soyutlama;

public interface MicrosoftIslemler {

    void lisansCheckEt();

}
