package com.yildirimholding.scm.soyutlama;

public class OyuuuunIslemlerrrPC {

    public String oyunDownload(){
        return "CS-GO";
    }

    public void oyunPlay(Integer oyunId){
        System.out.println(oyunId + " oyunu oynanıyor bilgisayarda");
    }

}
