package tr.com.erkanholding.pys;

public class Ogrenci {

    public String ad;
    public int yas;
}
