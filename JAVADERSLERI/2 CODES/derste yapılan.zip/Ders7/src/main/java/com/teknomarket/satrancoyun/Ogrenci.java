package com.teknomarket.satrancoyun;

public class Ogrenci {

    public String adSoyad;
    public int yas;

    public void ekranaAdiniYazdir() {
        System.out.println("Adı: " + adSoyad);
    }

    // new Ogrenci();
    public Ogrenci() {
        System.out.println("memory'de öğrenci için yer aldım");
        yas = 20;
    }


    public class Mahmut {

    }


}
