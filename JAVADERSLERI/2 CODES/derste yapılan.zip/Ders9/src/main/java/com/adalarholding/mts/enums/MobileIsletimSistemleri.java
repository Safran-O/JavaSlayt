package com.adalarholding.mts.enums;

public enum MobileIsletimSistemleri {

    ANDROID,
    IOS,
    HARMONY,
    WINMOBILE

}
