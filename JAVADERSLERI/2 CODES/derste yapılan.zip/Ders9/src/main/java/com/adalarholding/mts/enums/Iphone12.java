package com.adalarholding.mts.enums;

public class Iphone12 {

    private String model;
    private String uretimYili;
    private String isletimSistemi;


    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getUretimYili() {
        return uretimYili;
    }

    public void setUretimYili(String uretimYili) {
        this.uretimYili = uretimYili;
    }

    public String getIsletimSistemi() {
        return isletimSistemi;
    }

    public void setIsletimSistemi(String isletimSistemi) {
        this.isletimSistemi = isletimSistemi;
    }
}
