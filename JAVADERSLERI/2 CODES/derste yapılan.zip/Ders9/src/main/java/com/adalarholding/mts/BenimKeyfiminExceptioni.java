package com.adalarholding.mts;

public class BenimKeyfiminExceptioni extends Exception {

    @Override
    public String getMessage() {
        return "hele hele helhele";
    }
}
